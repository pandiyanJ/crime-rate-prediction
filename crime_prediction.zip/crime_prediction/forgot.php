<?php
include "db.php";
$msg="";

if(isset($_POST['reset'])){

$email=$_POST['email'];
$newpass=md5($_POST['password']);

$check=$conn->query("SELECT * FROM users WHERE email='$email'");

if($check->num_rows>0){

$conn->query("UPDATE users SET password='$newpass' WHERE email='$email'");
$msg="Password Updated Successfully!";

}else{
$msg="Email Not Found!";
}
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Forgot Password</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="box">
<h2>Reset Password</h2>

<form method="post">
<input type="email" name="email" placeholder="Enter Email" required>
<input type="password" name="password" placeholder="New Password" required>
<button name="reset">Reset Password</button>
</form>

<div class="msg"><?php echo $msg; ?></div>

<br>
<a href="login.php">Back to Login</a>

</div>

</body>
</html>