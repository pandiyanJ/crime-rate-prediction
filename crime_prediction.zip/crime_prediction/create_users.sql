DROP TABLE IF EXISTS users;
CREATE TABLE users(
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(50),
email VARCHAR(50) UNIQUE,
dob DATE,
mobile VARCHAR(15) UNIQUE,
password VARCHAR(255),
role VARCHAR(20),
badge_id VARCHAR(50)
);

-- Trigger to limit admins to 3
DELIMITER $$
CREATE TRIGGER limit_admin_count
BEFORE INSERT ON users
FOR EACH ROW
BEGIN
    IF NEW.role = 'admin' THEN
        IF (SELECT COUNT(*) FROM users WHERE role = 'admin') >= 3 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Admin limit reached (3 only)';
        END IF;
    END IF;
END$$
DELIMITER ;