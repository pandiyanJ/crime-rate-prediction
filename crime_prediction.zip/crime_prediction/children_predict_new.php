<?php
include "db.php";

if (!isset($_POST['area'], $_POST['crime'], $_POST['year'])) {
    die("Invalid input");
}

$area  = trim($_POST['area']);
$crime = trim($_POST['crime']);
$year  = (int)$_POST['year'];

$sql = "SELECT year, cases FROM children_crimes
        WHERE area='$area'
        AND crime_type='$crime'
        ORDER BY year ASC";

$res = $conn->query($sql);

$dbData = array();
$latestYear = 0;

while ($row = $res->fetch_assoc()) {
    $y = (int)$row['year'];
    $dbData[$y] = (int)$row['cases'];
    if ($y > $latestYear) {
        $latestYear = $y;
    }
}

if (empty($dbData)) {
    die("No records found");
}

if ($year <= $latestYear) {
    if (isset($dbData[$year])) {
        $prediction = $dbData[$year];
        $trend = "Actual historical record for the year $year.";
    } else {
        $prediction = 0;
        $trend = "No historical data available for this specific year.";
    }
} else {
    $currentYear = $latestYear + 1;
    while ($currentYear <= $year) {
        $recentCases = array_slice($dbData, -5, 5, true);
        $count = count($recentCases);
        
        $sum = 0;
        foreach ($recentCases as $val) {
            $sum += $val;
        }
        $avg = $sum / $count;
        
        $first_val = 0;
        $last_val = 0;
        $idx = 0;
        foreach ($recentCases as $val) {
            if ($idx == 0) $first_val = $val;
            if ($idx == $count - 1) $last_val = $val;
            $idx++;
        }
        
        $trend_adj = ($last_val - $first_val) / $count;
        
        $dbData[$currentYear] = round($avg + $trend_adj);
        $currentYear++;
    }
    $prediction = $dbData[$year];
    $trend = "Projected recursively using a 5-year rolling average trend model.";
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Children Crime Prediction</title>
<link rel="stylesheet" href="style.css">
</head>
<body class="auth-page">
    <div class="box">
        <h2>Children Crime Prediction</h2>
        <p style="margin-bottom: 10px; color: #b0c4de;"><b>Area :</b> <?php echo htmlspecialchars($area); ?></p>
        <p style="margin-bottom: 15px; color: #b0c4de;"><b>Crime :</b> <?php echo htmlspecialchars($crime); ?></p>
        <p style="margin-bottom: 20px; font-size: 18px;"><b>Predicted Cases for <?php echo $year; ?> :</b> <span style="font-size: 24px; color: #00e5ff; font-weight: bold;"><?php echo $prediction; ?></span></p>
        <p style="margin-bottom: 25px; font-size: 14px; color: #8fa3b0;"><b>Reason:</b> <?php echo $trend; ?></p>
        <button onclick="history.back()">Back</button>
    </div>
</body>
</html>