<?php
session_start();
include "db.php";

if(!isset($_SESSION['uid'])){
    header("Location: index.html");
    exit();
}

$isAdmin = ($_SESSION['role'] === 'admin');

// For Users: Fetch last 10 years of data for the chart and table.
$crimeTypesData = array(); // Will hold data structured for multiple charts
$tableData = array();

if (!$isAdmin) {
    // 1. Fetch data for each crime type over the years
    $q = "
        SELECT year, crime_type, SUM(cases) as total_cases 
        FROM (
            SELECT year, crime_type, cases FROM children_crimes
            UNION ALL
            SELECT year, crime_type, cases FROM types_crimes
        ) as combined
        GROUP BY year, crime_type
        ORDER BY year ASC, crime_type ASC
    ";
    
    $res = $conn->query($q);
    $allYears = array();
    if($res){
        while($row = $res->fetch_assoc()){
            $y = $row['year'];
            $c = $row['crime_type'];
            
            if(!in_array($y, $allYears)) $allYears[] = $y;
            
            if(!isset($crimeTypesData[$c])) {
                $crimeTypesData[$c] = array();
            }
            $crimeTypesData[$c][$y] = $row['total_cases'];
            
            // For the table, we'll organize by year -> crime type -> cases
            if(!isset($tableData[$y])) {
                $tableData[$y] = array();
            }
            $tableData[$y][$c] = $row['total_cases'];
        }
    }
    
    // Sort table data descending
    krsort($tableData);
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<link rel="stylesheet" href="style.css">
<style>
    /* Dashboard Specific Overrides */
    .btn-grid {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 15px;
    }
    
    .charts-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: 30px;
        margin-top: 20px;
    }
    
    .chart-container {
        width: 100%;
        min-height: 350px;
        background: var(--glass-bg);
        padding: 25px;
        border-radius: 20px;
        border: 1px solid var(--glass-border);
        backdrop-filter: var(--glass-blur);
        -webkit-backdrop-filter: var(--glass-blur);
        display: flex;
        flex-direction: column;
    }

    .bar-chart {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        margin-top: 15px;
    }

    .bar-item {
        margin-bottom: 12px;
    }

    .bar-label {
        display: flex;
        justify-content: space-between;
        font-size: 0.85rem;
        color: var(--text-secondary);
        margin-bottom: 4px;
    }

    .bar-label span:first-child {
        font-weight: 600;
        color: #fff;
    }

    .bar-track {
        height: 8px;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 10px;
        overflow: hidden;
    }

    .bar-fill {
        height: 100%;
        background: linear-gradient(90deg, #00e5ff, #00a8ff);
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 229, 255, 0.5);
        transition: width 1s ease-in-out;
    }

    .chart-title {
        font-size: 1.1rem;
        font-weight: 700;
        color: var(--accent-color);
        margin-bottom: 10px;
        border-bottom: 1px solid var(--glass-border);
        padding-bottom: 8px;
    }
</style>
</head>
<body>
<center>
<div class="dashboard-container">
    
    <div class="panel-glass" style="text-align: center;">
        <h1>
            <?php echo $isAdmin ? 'Admin Dashboard' : 'Crime Analysis Dashboard'; ?>
        </h1>
        <p style="color: var(--text-secondary);">Welcome to the Crime Prediction System</p>
    </div>

    <div class="panel-glass">
        <h2>Crime Prediction</h2>
        <div class="btn-grid">
            <a href="children.html" class="btn-action">Children Crime Prediction</a>
            <a href="types.html" class="btn-action">Types of Crime Prediction</a>
            <?php if($isAdmin): ?>
                <a href="add_record.php" class="btn-action" style="border-color: var(--success-color); color: var(--success-color);">Add New Record</a>
            <?php endif; ?>
            <a href="logout.php" class="btn-action btn-logout">Logout</a>
        </div>
    </div>

    <?php if(!$isAdmin): ?>
    <div class="panel-glass">
        <h2>Crime Trends (By Category)</h2>
        <div class="charts-grid">
            <?php 
            foreach($crimeTypesData as $crime => $data): 
                // Find max value for this specific crime to scale bars
                $maxVal = (count($data) > 0) ? max($data) : 1;
                if($maxVal == 0) $maxVal = 1;
            ?>
                <div class="chart-container">
                    <div class="chart-title"><?php echo htmlspecialchars($crime); ?></div>
                    <div class="bar-chart">
                        <?php 
                        // Show only last 7 years to fit container nicely without JS scrolling
                        $yearsToShow = array_slice($allYears, -7);
                        foreach($yearsToShow as $y): 
                            $val = isset($data[$y]) ? $data[$y] : 0;
                            $percent = ($val / $maxVal) * 100;
                        ?>
                            <div class="bar-item">
                                <div class="bar-label">
                                    <span>Year <?php echo $y; ?></span>
                                    <span><?php echo $val; ?> cases</span>
                                </div>
                                <div class="bar-track">
                                    <div class="bar-fill" style="width: <?php echo $percent; ?>%;"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="panel-glass">
        <h2>Recent Historical Data Summary</h2>
        <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Year</th>
                    <?php 
                    // Get all unique crime types for table headers
                    $allCrimes = array_keys($crimeTypesData);
                    sort($allCrimes);
                    foreach($allCrimes as $crime) {
                        echo "<th>" . htmlspecialchars($crime) . "</th>";
                    }
                    ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach($tableData as $year => $crimes): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($year); ?></strong></td>
                    <?php foreach($allCrimes as $crime): ?>
                        <td><?php echo isset($crimes[$crime]) ? htmlspecialchars($crimes[$crime]) : '0'; ?></td>
                    <?php endforeach; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
    <?php endif; ?>

</div>
</center>
</body>
</html>