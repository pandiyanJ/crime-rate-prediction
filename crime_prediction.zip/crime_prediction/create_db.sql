DROP DATABASE IF EXISTS crime_db;
CREATE DATABASE crime_db;
USE crime_db;

-- ============================
-- USERS
-- ============================
DROP TABLE IF EXISTS users;
CREATE TABLE users(
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(50),
 email VARCHAR(50) UNIQUE,
 dob DATE,
 mobile VARCHAR(15) UNIQUE,
 password VARCHAR(255),
 role VARCHAR(20),
 badge_id VARCHAR(50)
);

-- Trigger to limit admins to 3
DELIMITER $$
CREATE TRIGGER limit_admin_count
BEFORE INSERT ON users
FOR EACH ROW
BEGIN
    IF NEW.role = 'admin' THEN
        IF (SELECT COUNT(*) FROM users WHERE role = 'admin') >= 3 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Admin limit reached (3 only)';
        END IF;
    END IF;
END$$
DELIMITER ;

-- Admin insert
INSERT INTO users (name, email, dob, mobile, password, role, badge_id) VALUES
('Admin User', 'admin@gmail.com', '1980-01-01', '9876543210', 'admin123', 'admin', 'ADM001');

-- Police insert
INSERT INTO users (name, email, dob, mobile, password, role, badge_id) VALUES
('Police Officer', 'police@gmail.com', '1985-05-05', '9876543211', 'police123', 'police', 'POL001');

-- User insert
INSERT INTO users (name, email, dob, mobile, password, role, badge_id) VALUES
('Regular User', 'user@gmail.com', '1990-10-10', '9876543212', 'user123', 'user', 'USR001');

-- ============================
-- CHILDREN CRIMES
-- ============================
CREATE TABLE children_crimes(
 id INT AUTO_INCREMENT PRIMARY KEY,
 year INT NOT NULL,
 area VARCHAR(40) NOT NULL,
 crime_type VARCHAR(40) NOT NULL,
 cases INT NOT NULL
);

-- AREAS = 4
-- CRIMES = 3
-- YEARS = 2016–2025 (10 YEARS)

INSERT INTO children_crimes (year,area,crime_type,cases) VALUES

-- Chennai
(2016,'Chennai','Child Labour',342),
(2017,'Chennai','Child Labour',315),
(2018,'Chennai','Child Labour',328),
(2019,'Chennai','Child Labour',290),
(2020,'Chennai','Child Labour',112),
(2021,'Chennai','Child Labour',145),
(2022,'Chennai','Child Labour',360),
(2023,'Chennai','Child Labour',385),
(2024,'Chennai','Child Labour',310),
(2025,'Chennai','Child Labour',325),

(2016,'Chennai','Child Abuse',215),
(2017,'Chennai','Child Abuse',230),
(2018,'Chennai','Child Abuse',242),
(2019,'Chennai','Child Abuse',255),
(2020,'Chennai','Child Abuse',180),
(2021,'Chennai','Child Abuse',195),
(2022,'Chennai','Child Abuse',270),
(2023,'Chennai','Child Abuse',295),
(2024,'Chennai','Child Abuse',312),
(2025,'Chennai','Child Abuse',340),

(2016,'Chennai','Kidnapping',108),
(2017,'Chennai','Kidnapping',95),
(2018,'Chennai','Kidnapping',115),
(2019,'Chennai','Kidnapping',122),
(2020,'Chennai','Kidnapping',54),
(2021,'Chennai','Kidnapping',78),
(2022,'Chennai','Kidnapping',135),
(2023,'Chennai','Kidnapping',150),
(2024,'Chennai','Kidnapping',142),
(2025,'Chennai','Kidnapping',165),

-- Coimbatore
(2016,'Coimbatore','Child Labour',185),
(2017,'Coimbatore','Child Labour',170),
(2018,'Coimbatore','Child Labour',192),
(2019,'Coimbatore','Child Labour',168),
(2020,'Coimbatore','Child Labour',65),
(2021,'Coimbatore','Child Labour',85),
(2022,'Coimbatore','Child Labour',210),
(2023,'Coimbatore','Child Labour',195),
(2024,'Coimbatore','Child Labour',225),
(2025,'Coimbatore','Child Labour',205),

(2016,'Coimbatore','Child Abuse',110),
(2017,'Coimbatore','Child Abuse',125),
(2018,'Coimbatore','Child Abuse',105),
(2019,'Coimbatore','Child Abuse',140),
(2020,'Coimbatore','Child Abuse',85),
(2021,'Coimbatore','Child Abuse',92),
(2022,'Coimbatore','Child Abuse',155),
(2023,'Coimbatore','Child Abuse',168),
(2024,'Coimbatore','Child Abuse',175),
(2025,'Coimbatore','Child Abuse',190),

(2016,'Coimbatore','Kidnapping',55),
(2017,'Coimbatore','Kidnapping',48),
(2018,'Coimbatore','Kidnapping',62),
(2019,'Coimbatore','Kidnapping',58),
(2020,'Coimbatore','Kidnapping',25),
(2021,'Coimbatore','Kidnapping',34),
(2022,'Coimbatore','Kidnapping',70),
(2023,'Coimbatore','Kidnapping',82),
(2024,'Coimbatore','Kidnapping',75),
(2025,'Coimbatore','Kidnapping',88),

-- Madurai
(2016,'Madurai','Child Labour',145),
(2017,'Madurai','Child Labour',132),
(2018,'Madurai','Child Labour',150),
(2019,'Madurai','Child Labour',128),
(2020,'Madurai','Child Labour',45),
(2021,'Madurai','Child Labour',62),
(2022,'Madurai','Child Labour',165),
(2023,'Madurai','Child Labour',155),
(2024,'Madurai','Child Labour',175),
(2025,'Madurai','Child Labour',160),

(2016,'Madurai','Child Abuse',85),
(2017,'Madurai','Child Abuse',92),
(2018,'Madurai','Child Abuse',80),
(2019,'Madurai','Child Abuse',105),
(2020,'Madurai','Child Abuse',65),
(2021,'Madurai','Child Abuse',70),
(2022,'Madurai','Child Abuse',115),
(2023,'Madurai','Child Abuse',125),
(2024,'Madurai','Child Abuse',132),
(2025,'Madurai','Child Abuse',145),

(2016,'Madurai','Kidnapping',42),
(2017,'Madurai','Kidnapping',35),
(2018,'Madurai','Kidnapping',48),
(2019,'Madurai','Kidnapping',45),
(2020,'Madurai','Kidnapping',15),
(2021,'Madurai','Kidnapping',22),
(2022,'Madurai','Kidnapping',55),
(2023,'Madurai','Kidnapping',65),
(2024,'Madurai','Kidnapping',58),
(2025,'Madurai','Kidnapping',72),

-- Salem
(2016,'Salem','Child Labour',112),
(2017,'Salem','Child Labour',105),
(2018,'Salem','Child Labour',120),
(2019,'Salem','Child Labour',98),
(2020,'Salem','Child Labour',35),
(2021,'Salem','Child Labour',48),
(2022,'Salem','Child Labour',135),
(2023,'Salem','Child Labour',125),
(2024,'Salem','Child Labour',142),
(2025,'Salem','Child Labour',130),

(2016,'Salem','Child Abuse',65),
(2017,'Salem','Child Abuse',72),
(2018,'Salem','Child Abuse',60),
(2019,'Salem','Child Abuse',85),
(2020,'Salem','Child Abuse',45),
(2021,'Salem','Child Abuse',52),
(2022,'Salem','Child Abuse',95),
(2023,'Salem','Child Abuse',105),
(2024,'Salem','Child Abuse',112),
(2025,'Salem','Child Abuse',120),

(2016,'Salem','Kidnapping',32),
(2017,'Salem','Kidnapping',28),
(2018,'Salem','Kidnapping',35),
(2019,'Salem','Kidnapping',30),
(2020,'Salem','Kidnapping',12),
(2021,'Salem','Kidnapping',18),
(2022,'Salem','Kidnapping',42),
(2023,'Salem','Kidnapping',48),
(2024,'Salem','Kidnapping',45),
(2025,'Salem','Kidnapping',55);

-- ============================
-- TYPES OF CRIMES
-- ============================
CREATE TABLE types_crimes(
 id INT AUTO_INCREMENT PRIMARY KEY,
 year INT NOT NULL,
 area VARCHAR(40) NOT NULL,
 crime_type VARCHAR(40) NOT NULL,
 cases INT NOT NULL
);

INSERT INTO types_crimes (year,area,crime_type,cases) VALUES

-- Chennai
(2016,'Chennai','Cyber Crime',452),
(2017,'Chennai','Cyber Crime',580),
(2018,'Chennai','Cyber Crime',725),
(2019,'Chennai','Cyber Crime',890),
(2020,'Chennai','Cyber Crime',1420),
(2021,'Chennai','Cyber Crime',1685),
(2022,'Chennai','Cyber Crime',1945),
(2023,'Chennai','Cyber Crime',2310),
(2024,'Chennai','Cyber Crime',2750),
(2025,'Chennai','Cyber Crime',3025),

(2016,'Chennai','Theft',1845),
(2017,'Chennai','Theft',1760),
(2018,'Chennai','Theft',1810),
(2019,'Chennai','Theft',1695),
(2020,'Chennai','Theft',840),
(2021,'Chennai','Theft',1050),
(2022,'Chennai','Theft',1920),
(2023,'Chennai','Theft',2050),
(2024,'Chennai','Theft',1985),
(2025,'Chennai','Theft',2140),

(2016,'Chennai','Assault',950),
(2017,'Chennai','Assault',1020),
(2018,'Chennai','Assault',985),
(2019,'Chennai','Assault',1105),
(2020,'Chennai','Assault',620),
(2021,'Chennai','Assault',715),
(2022,'Chennai','Assault',1240),
(2023,'Chennai','Assault',1310),
(2024,'Chennai','Assault',1280),
(2025,'Chennai','Assault',1365),

-- Coimbatore
(2016,'Coimbatore','Cyber Crime',185),
(2017,'Coimbatore','Cyber Crime',240),
(2018,'Coimbatore','Cyber Crime',315),
(2019,'Coimbatore','Cyber Crime',420),
(2020,'Coimbatore','Cyber Crime',780),
(2021,'Coimbatore','Cyber Crime',920),
(2022,'Coimbatore','Cyber Crime',1080),
(2023,'Coimbatore','Cyber Crime',1250),
(2024,'Coimbatore','Cyber Crime',1480),
(2025,'Coimbatore','Cyber Crime',1650),

(2016,'Coimbatore','Theft',925),
(2017,'Coimbatore','Theft',880),
(2018,'Coimbatore','Theft',910),
(2019,'Coimbatore','Theft',865),
(2020,'Coimbatore','Theft',420),
(2021,'Coimbatore','Theft',510),
(2022,'Coimbatore','Theft',945),
(2023,'Coimbatore','Theft',1020),
(2024,'Coimbatore','Theft',980),
(2025,'Coimbatore','Theft',1080),

(2016,'Coimbatore','Assault',480),
(2017,'Coimbatore','Assault',495),
(2018,'Coimbatore','Assault',460),
(2019,'Coimbatore','Assault',520),
(2020,'Coimbatore','Assault',295),
(2021,'Coimbatore','Assault',345),
(2022,'Coimbatore','Assault',560),
(2023,'Coimbatore','Assault',590),
(2024,'Coimbatore','Assault',575),
(2025,'Coimbatore','Assault',615),

-- Madurai
(2016,'Madurai','Cyber Crime',110),
(2017,'Madurai','Cyber Crime',145),
(2018,'Madurai','Cyber Crime',190),
(2019,'Madurai','Cyber Crime',240),
(2020,'Madurai','Cyber Crime',480),
(2021,'Madurai','Cyber Crime',560),
(2022,'Madurai','Cyber Crime',680),
(2023,'Madurai','Cyber Crime',810),
(2024,'Madurai','Cyber Crime',950),
(2025,'Madurai','Cyber Crime',1080),

(2016,'Madurai','Theft',740),
(2017,'Madurai','Theft',715),
(2018,'Madurai','Theft',735),
(2019,'Madurai','Theft',690),
(2020,'Madurai','Theft',310),
(2021,'Madurai','Theft',395),
(2022,'Madurai','Theft',760),
(2023,'Madurai','Theft',810),
(2024,'Madurai','Theft',780),
(2025,'Madurai','Theft',840),

(2016,'Madurai','Assault',385),
(2017,'Madurai','Assault',410),
(2018,'Madurai','Assault',395),
(2019,'Madurai','Assault',435),
(2020,'Madurai','Assault',215),
(2021,'Madurai','Assault',260),
(2022,'Madurai','Assault',445),
(2023,'Madurai','Assault',480),
(2024,'Madurai','Assault',465),
(2025,'Madurai','Assault',520),

-- Salem
(2016,'Salem','Cyber Crime',85),
(2017,'Salem','Cyber Crime',110),
(2018,'Salem','Cyber Crime',145),
(2019,'Salem','Cyber Crime',175),
(2020,'Salem','Cyber Crime',350),
(2021,'Salem','Cyber Crime',420),
(2022,'Salem','Cyber Crime',510),
(2023,'Salem','Cyber Crime',610),
(2024,'Salem','Cyber Crime',720),
(2025,'Salem','Cyber Crime',840),

(2016,'Salem','Theft',610),
(2017,'Salem','Theft',580),
(2018,'Salem','Theft',605),
(2019,'Salem','Theft',560),
(2020,'Salem','Theft',245),
(2021,'Salem','Theft',315),
(2022,'Salem','Theft',620),
(2023,'Salem','Theft',660),
(2024,'Salem','Theft',635),
(2025,'Salem','Theft',690),

(2016,'Salem','Assault',310),
(2017,'Salem','Assault',335),
(2018,'Salem','Assault',320),
(2019,'Salem','Assault',355),
(2020,'Salem','Assault',175),
(2021,'Salem','Assault',210),
(2022,'Salem','Assault',365),
(2023,'Salem','Assault',395),
(2024,'Salem','Assault',380),
(2025,'Salem','Assault',425);
