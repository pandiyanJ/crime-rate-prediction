<?php
include "db.php";
$msg="";

if(isset($_POST['register'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $dob=$_POST['dob'];
    $mobile=$_POST['mobile'];
    $password=$_POST['password'];
    $cpassword=$_POST['cpassword'];
    $user_type=$_POST['user_type'];
    $badge_id=isset($_POST['badge_id']) ? $_POST['badge_id'] : '';
    $role = ($user_type === 'police') ? 'police' : 'user';

    if($password != $cpassword) {
        $msg="<span class='msg'>Passwords do not match!</span>";
    } else {
        $pass=$password; // Plain text
        $check=$conn->query("SELECT * FROM users WHERE email='$email' OR mobile='$mobile'");

        if($check->num_rows>0){
            $msg="<span class='msg'>Account with this email or mobile already exists!</span>";
        }else{
            $conn->query("INSERT INTO users(name,email,dob,mobile,password,role,badge_id) VALUES('$name','$email','$dob','$mobile','$pass','$role','$badge_id')");
            $msg="<span class='msg success'>Registration Success!</span>";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>User Register</title>
<link rel="stylesheet" href="style.css">
<style>
/* CSS-only toggle for Badge ID */
#badge_container {
    display: none;
}
#police_radio:checked ~ #badge_container {
    display: block;
}
</style>
</head>
<body class="auth-page">

<div class="box">
    <h2>User Register</h2>

    <form method="post">
        <div class="radio-group" style="display: flex; flex-direction: column; align-items: flex-start; gap: 10px;">
            <label><input type="radio" name="user_type" value="user" id="normal_radio" checked> Normal Public</label>
            <label><input type="radio" name="user_type" value="police" id="police_radio"> Police Officer</label>
            
            <!-- Moved container here to be a sibling for CSS toggle -->
            <div class="input-group" id="badge_container" style="width: 100%; margin-top: 10px;">
                <input type="text" name="badge_id" placeholder="Police Badge ID">
            </div>
        </div>

        <div class="input-group">
            <input type="text" name="name" placeholder="Full Name" required>
        </div>
        <div class="input-group">
            <input type="email" name="email" placeholder="Email Address" required>
        </div>
        
        <div class="input-group">
            <input type="date" name="dob" placeholder="Date of Birth" required title="Date of Birth">
        </div>
        <div class="input-group">
            <input type="tel" name="mobile" placeholder="Mobile Number" required pattern="[0-9]{10}" title="10 digit mobile number">
        </div>
        <div class="input-group">
            <input type="password" name="password" placeholder="Password" required>
        </div>
        <div class="input-group">
            <input type="password" name="cpassword" placeholder="Confirm Password" required>
        </div>
        <button name="register">Register</button>
    </form>
    
    <div><?php echo $msg; ?></div>

    <div class="links">
        <a href="user_login.php">Already have an account? Login here</a>
        <a href="index.html">Back to Home</a>
    </div>
</div>

</body>
</html>