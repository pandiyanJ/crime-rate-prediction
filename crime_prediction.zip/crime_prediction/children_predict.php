<?php
include "db.php";

if (!isset($_POST['area'], $_POST['crime'], $_POST['year'])) {
    die("Invalid input");
}

$area  = trim($_POST['area']);
$crime = trim($_POST['crime']);
$year  = (int)$_POST['year'];

$sql = "SELECT year, cases FROM children_crimes
        WHERE area='$area'
        AND crime_type='$crime'
        ORDER BY year ASC";

$res = $conn->query($sql);

$dbData = array();
$latestYear = 0;

while ($row = $res->fetch_assoc()) {
    $y = (int)$row['year'];
    $dbData[$y] = (int)$row['cases'];
    if ($y > $latestYear) {
        $latestYear = $y;
    }
}

if (empty($dbData)) {
    die("No records found");
}

if ($year <= $latestYear) {
    if (isset($dbData[$year])) {
        $prediction = $dbData[$year];
        $trend = "Actual historical record for the year $year.";
    } else {
        $prediction = 0;
        $trend = "No historical data available for this specific year.";
    }
} else {
    $currentYear = $latestYear + 1;
    while ($currentYear <= $year) {
        $recentCases = array_slice($dbData, -5, 5, true);
        $count = count($recentCases);
        
        $sum = 0;
        foreach ($recentCases as $val) {
            $sum += $val;
        }
        $avg = $sum / $count;
        
        $dbData[$currentYear] = round($avg);
        $currentYear++;
    }
    $prediction = $dbData[$year];
    $trend = "Projected strictly using the average of the previous 5 years.";
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Children Crime Prediction</title>
<link rel="stylesheet" href="style.css">
</head>
<body class="auth-page">
    <div class="box">
        <h2>Crime Prediction Result</h2>
        <div style="text-align: left; margin-bottom: 20px;">
            <p style="margin-bottom: 10px; color: var(--text-secondary); font-size: 16px;">
                <b style="color: var(--accent-color);">Area:</b> <?php echo htmlspecialchars($area); ?>
            </p>
            <p style="margin-bottom: 15px; color: var(--text-secondary); font-size: 16px;">
                <b style="color: var(--accent-color);">Crime Type:</b> <?php echo htmlspecialchars($crime); ?>
            </p>
            <div style="background: rgba(0,0,0,0.2); padding: 20px; border-radius: 15px; border: 1px solid var(--glass-border); text-align: center; margin-bottom: 20px;">
                <p style="margin-bottom: 5px; font-size: 14px; color: var(--text-secondary);">Predicted cases for <?php echo $year; ?></p>
                <span style="font-size: 48px; color: var(--accent-color); font-weight: 800; text-shadow: 0 0 20px rgba(0, 229, 255, 0.4);"><?php echo $prediction; ?></span>
            </div>
            <p style="font-size: 14px; color: var(--text-secondary); line-height: 1.4;">
                <b style="color: var(--accent-color);">Trend Analysis:</b><br>
                <?php echo $trend; ?>
            </p>
        </div>
        <button onclick="history.back()">Back to Prediction</button>
    </div>
</body>
</html>