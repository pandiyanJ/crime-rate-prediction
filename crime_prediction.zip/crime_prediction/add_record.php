<?php
session_start();
include "db.php";

$msg="";

if(!isset($_SESSION['uid']) || $_SESSION['role'] !== 'admin'){
    header("Location: index.html");
    exit();
}

if(isset($_POST['add'])){
    $table_type = $_POST['table_type']; // children_crimes or types_crimes
    $year = $_POST['year'];
    $area = $_POST['area'];
    $crime_type = $_POST['crime_type'];
    $cases = $_POST['cases'];

    $conn->query("INSERT INTO $table_type (year, area, crime_type, cases) VALUES ('$year', '$area', '$crime_type', '$cases')");
    $msg = "<span class='msg success'>Record added successfully!</span>";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Record</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<center>
<div class="box">
    <h2>Add New Crime Record</h2>

    <form method="post">
        <div class="input-group">
            <select name="table_type" required>
                <option value="">Select Category</option>
                <option value="children_crimes">Children Crimes</option>
                <option value="types_crimes">Types of Crimes</option>
            </select>
        </div>

        <div class="input-group">
            <select name="area" required>
                <option value="">Select Area</option>
                <option value="Chennai">Chennai</option>
                <option value="Coimbatore">Coimbatore</option>
                <option value="Madurai">Madurai</option>
                <option value="Salem">Salem</option>
            </select>
        </div>

        <div class="input-group">
            <select name="crime_type" required>
                <option value="">Select Crime Type</option>
                <option value="Child Labour">Child Labour</option>
                <option value="Child Abuse">Child Abuse</option>
                <option value="Kidnapping">Kidnapping</option>
                <option value="Cyber Crime">Cyber Crime</option>
                <option value="Theft">Theft</option>
                <option value="Assault">Assault</option>
            </select>
        </div>

        <div class="input-group">
            <input type="number" name="year" placeholder="Year (e.g., 2026)" required min="2000" max="2100">
        </div>

        <div class="input-group">
            <input type="number" name="cases" placeholder="Number of Cases" required min="0">
        </div>

        <button name="add">Add Record</button>
    </form>

    <div><?php echo $msg; ?></div>

    <div class="links" style="margin-top:20px;">
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</div>
</center>
</body>
</html>
