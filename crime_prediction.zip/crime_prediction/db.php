<?php
$conn = new mysqli("localhost","root","","crime_db");

if($conn->connect_error){
    die("DB Failed");
}
?>
