<?php
// Mock POST request to children_predict.php to see the error output
$_POST['area'] = 'Chennai';
$_POST['crime'] = 'Child Labour';
$_POST['year'] = '2026';

include 'children_predict_new.php';
?>
