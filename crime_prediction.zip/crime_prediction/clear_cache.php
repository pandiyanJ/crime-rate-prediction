<?php
// Force reset OPcache
if (function_exists('opcache_reset')) {
    opcache_reset();
    echo "OPcache reset successfully.\n";
} else {
    echo "OPcache is not enabled or function does not exist.\n";
}

// Alternatively, try clearing APC cache if it exists on older WAMP configs
if (function_exists('apc_clear_cache')) {
    apc_clear_cache();
    echo "APC cache cleared.\n";
}
?>
