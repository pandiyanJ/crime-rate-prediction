<?php
session_start();
include "db.php";

$msg="";

if(isset($_POST['login'])){

$email=$_POST['email'];
$pass=$_POST['password'];

$r=$conn->query("SELECT * FROM users WHERE email='$email'");

if($r->num_rows>0){

$row=$r->fetch_assoc();

if(md5($pass)==$row['password']){

$_SESSION['uid']=$row['id'];
$_SESSION['role']=$row['role'];

header("Location: dashboard.php");
exit();

}else{
$msg="Wrong Password!";
}

}else{
$msg="User Not Found!";
}

}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link rel="stylesheet" href="style.css">
</head>

<body class="auth-page">

<div class="box">

<h2>Crime Login</h2>

<form method="post">

<input type="email" name="email" placeholder="Email" required>

<input type="password" name="password" placeholder="Password" required>

<button name="login">Login</button>

</form>

<div class="msg"><?php echo $msg; ?></div>

<br>

<a href="forgot.php">Forgot Password</a><br>
<a href="index.html" class="btn">Index</a>
</div>

</body>
</html>