<?php
include "db.php";
$msg="";

if(isset($_POST['reset'])){
    $email=$_POST['email'];
    $recovery_type=$_POST['recovery_type'];
    $recovery_val=$_POST['recovery_val'];
    $newpass=$_POST['password'];

    if($recovery_type == 'dob') {
        $recovery_val=$_POST['recovery_dob'];
        $check=$conn->query("SELECT * FROM users WHERE email='$email' AND dob='$recovery_val' AND (role='user' OR role='police')");
    } else {
        $recovery_val=$_POST['recovery_mobile'];
        $check=$conn->query("SELECT * FROM users WHERE email='$email' AND mobile='$recovery_val' AND (role='user' OR role='police')");
    }

    if($check->num_rows>0){
        $conn->query("UPDATE users SET password='$newpass' WHERE email='$email'");
        $msg="<span class='msg success'>Password Updated Successfully!</span>";
    }else{
        $msg="<span class='msg'>Details mismatched or User Not Found!</span>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>User Forgot Password</title>
<link rel="stylesheet" href="style.css">
<style>
#mobile_input, #dob_input { display: none; }
#radio_mobile:checked ~ #mobile_input { display: block; }
#radio_dob:checked ~ #dob_input { display: block; }
</style>
</head>
<body>

<div class="box">
    <h2>User Reset Password</h2>

    <form method="post">
        <div class="input-group">
            <input type="email" name="email" placeholder="Enter User Email" required>
        </div>
        
        <div class="radio-group" style="margin-top:15px; margin-bottom: 15px; display: flex; flex-direction: column; gap: 8px;">
            <label><input type="radio" name="recovery_type" value="mobile" id="radio_mobile" checked> Reset via Mobile Number</label>
            <label><input type="radio" name="recovery_type" value="dob" id="radio_dob"> Reset via Date of Birth</label>
            
            <div class="input-group" id="mobile_input" style="margin-top: 10px;">
                <input type="tel" name="recovery_mobile" placeholder="Enter Mobile Number">
            </div>
            <div class="input-group" id="dob_input" style="margin-top: 10px;">
                <input type="date" name="recovery_dob" placeholder="Date of Birth">
            </div>
        </div>

        <div class="input-group">
            <input type="password" name="password" placeholder="New Password" required>
        </div>
        <button name="reset">Reset Password</button>
    </form>

    <div><?php echo $msg; ?></div>

    <div class="links" style="margin-top:20px;">
        <a href="user_login.php">Back to User Login</a>
    </div>
</div>

</body>
</html>