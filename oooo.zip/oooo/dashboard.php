<?php
session_start();
include "db.php";

if(!isset($_SESSION['uid'])){
    header("Location: index.html");
    exit();
}

$isAdmin = ($_SESSION['role'] === 'admin');

// For Users: Fetch last 10 years of data for the chart and table.
$crimeTypesData = array(); // Will hold data structured for multiple charts
$tableData = array();

if (!$isAdmin) {
    // 1. Fetch data for each crime type over the years
    $q = "
        SELECT year, crime_type, SUM(cases) as total_cases 
        FROM (
            SELECT year, crime_type, cases FROM children_crimes
            UNION ALL
            SELECT year, crime_type, cases FROM types_crimes
        ) as combined
        GROUP BY year, crime_type
        ORDER BY year ASC, crime_type ASC
    ";
    
    $res = $conn->query($q);
    $allYears = array();
    if($res){
        while($row = $res->fetch_assoc()){
            $y = $row['year'];
            $c = $row['crime_type'];
            
            if(!in_array($y, $allYears)) $allYears[] = $y;
            
            if(!isset($crimeTypesData[$c])) {
                $crimeTypesData[$c] = array();
            }
            $crimeTypesData[$c][$y] = $row['total_cases'];
            
            // For the table, we'll organize by year -> crime type -> cases
            if(!isset($tableData[$y])) {
                $tableData[$y] = array();
            }
            $tableData[$y][$c] = $row['total_cases'];
        }
    }
    
    // Sort table data descending
    krsort($tableData);
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<link rel="stylesheet" href="style.css">
<?php if(!$isAdmin): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<?php endif; ?>
<style>
    /* Light Theme Overrides for Dashboard */
    body {
        background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
        color: #333;
    }
    
    .panel {
        background: rgba(255, 255, 255, 0.9);
        border: 1px solid rgba(0, 0, 0, 0.1);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        color: #333;
    }
    
    .panel h1, .panel h2 {
        color: #007bff !important;
        text-shadow: none !important;
    }
    
    .panel p {
        color: #666 !important;
    }

    .btn-action {
        background: #eef2f7;
        border: 2px solid #007bff;
        color: #007bff;
        padding: 25px;
        font-size: 20px;
        font-weight: 700;
        text-transform: uppercase;
        border-radius: 12px;
    }

    .btn-action:hover {
        background: #007bff;
        color: #fff;
        box-shadow: 0 10px 20px rgba(0, 123, 255, 0.2);
    }
    
    .btn-logout {
        border-color: #dc3545;
        color: #dc3545;
    }
    .btn-logout:hover {
        background: #dc3545;
    }

    /* Table Styles */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    th, td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #eee;
        color: #444;
    }
    th {
        color: #007bff;
        font-weight: 600;
        background: #f8f9fa;
        border-bottom: 2px solid #007bff;
    }
    tr:hover td {
        background: #f1f5f9;
    }
    
    .charts-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
        gap: 30px;
        margin-top: 20px;
    }
    .chart-container {
        width: 100%;
        height: 300px;
        background: #fff;
        padding: 15px;
        border-radius: 10px;
        border: 1px solid #eee;
    }
</style>
</head>
<body>

<div class="dashboard-container">
    
    <div class="panel" style="text-align: center;">
        <h1>
            <?php echo $isAdmin ? 'Admin Dashboard' : 'User/Police Dashboard'; ?>
        </h1>
        <p>Welcome to the Crime Prediction System</p>
    </div>

    <div class="panel">
        <h2>Crime Prediction</h2>
        <div class="btn-grid" style="display: flex; flex-wrap: wrap; justify-content: center; gap: 15px;">
            <a href="children.html" class="btn-action">Children Crime Prediction</a>
            <a href="types.html" class="btn-action">Types of Crime Prediction</a>
            <?php if($isAdmin): ?>
                <a href="add_record.php" class="btn-action" style="border-color: #28a745; color:#28a745;">Add New Record</a>
            <?php endif; ?>
            <a href="logout.php" class="btn-action btn-logout">Logout</a>
        </div>
    </div>

    <?php if(!$isAdmin): ?>
    <div class="panel">
        <h2>Crime Trends (By Category)</h2>
        <div class="charts-grid">
            <?php 
            $chartIndex = 0;
            foreach($crimeTypesData as $crime => $data): 
                $chartId = 'chart_' . md5($crime);
            ?>
                <div class="chart-container">
                    <canvas id="<?php echo $chartId; ?>"></canvas>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="panel">
        <h2>Recent Historical Data Summary</h2>
        <div style="overflow-x: auto;">
        <table>
            <thead>
                <tr>
                    <th>Year</th>
                    <?php 
                    // Get all unique crime types for table headers
                    $allCrimes = array_keys($crimeTypesData);
                    sort($allCrimes);
                    foreach($allCrimes as $crime) {
                        echo "<th>" . htmlspecialchars($crime) . "</th>";
                    }
                    ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach($tableData as $year => $crimes): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($year); ?></strong></td>
                    <?php foreach($allCrimes as $crime): ?>
                        <td><?php echo isset($crimes[$crime]) ? htmlspecialchars($crimes[$crime]) : '0'; ?></td>
                    <?php endforeach; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
    
    <script>
        const allYears = <?php echo json_encode(array_values($allYears)); ?>;
        
        <?php foreach($crimeTypesData as $crime => $data): 
            $chartId = 'chart_' . md5($crime);
            
            // Map data to ensure no missing years in arrays
            $chartValues = array();
            foreach($allYears as $y) {
                $chartValues[] = isset($data[$y]) ? $data[$y] : 0;
            }
        ?>
        new Chart(document.getElementById('<?php echo $chartId; ?>').getContext('2d'), {
            type: 'bar',
            data: {
                labels: allYears,
                datasets: [{
                    label: '<?php echo addslashes($crime); ?>',
                    data: <?php echo json_encode($chartValues); ?>,
                    backgroundColor: 'rgba(0, 123, 255, 0.6)',
                    borderColor: '#007bff',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
        <?php endforeach; ?>
    </script>
    <?php endif; ?>

</div>

</body>
</html>