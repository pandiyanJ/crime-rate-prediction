<?php
session_start();
include "db.php";
$msg="";

if(isset($_POST['login'])){
    $email=$_POST['email'];
    $pass=$_POST['password'];

    $r=$conn->query("SELECT * FROM users WHERE email='$email' AND role='admin'");

    if($r->num_rows>0){
        $row=$r->fetch_assoc();
        if($pass == $row['password']){
            $_SESSION['uid']=$row['id'];
            $_SESSION['role']=$row['role'];
            header("Location: dashboard.php");
            exit();
        }else{
            $msg="<span class='msg'>Wrong Password!</span>";
        }
    }else{
        $msg="<span class='msg'>Admin Not Found!</span>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="box">
    <h2>Admin Login</h2>
    <form method="post">
        <div class="input-group">
            <input type="email" name="email" placeholder="Email Address" required>
        </div>
        <div class="input-group">
            <input type="password" name="password" placeholder="Password" required>
        </div>
        <button name="login">Login</button>
    </form>
    <div><?php echo $msg; ?></div>
    <div class="links" style="margin-top:20px;">
        <a href="admin_register.php">Register as Admin</a>
        <a href="admin_forgot.php">Forgot Password?</a>
        <a href="index.html">Back to Home</a>
    </div>
</div>
</body>
</html>