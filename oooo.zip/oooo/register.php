<?php
include "db.php";
$msg="";

if(isset($_POST['register'])){

$name=$_POST['name'];
$email=$_POST['email'];
$pass=md5($_POST['password']);
$role=$_POST['role'];

$check=$conn->query("SELECT * FROM users WHERE email='$email'");

if($check->num_rows>0){
$msg="Already Account Exists!";
}else{

if($role=="admin"){
$c=$conn->query("SELECT * FROM users WHERE role='admin'");
if($c->num_rows>=3){
$msg="Admin limit reached (3 only)";
}else{
$conn->query("INSERT INTO users(name,email,password,role) VALUES('$name','$email','$pass','$role')");
$msg="Registration Success!";
}
}else{
$conn->query("INSERT INTO users(name,email,password,role) VALUES('$name','$email','$pass','$role')");
$msg="Registration Success!";
}
}
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="box">

<h2>Register</h2>

<form method="post">

<input type="text" name="name" placeholder="Name" required>

<input type="email" name="email" placeholder="Email" required>

<input type="password" name="password" placeholder="Password" required>

<select name="role">
<option value="user">User</option>
<option value="admin">Admin</option>
</select>

<button name="register">Register</button>

</form>
<a href="login.php" class="btn">Login</a>
<div class="msg"><?php echo $msg; ?></div>

</div>

</body>
</html>