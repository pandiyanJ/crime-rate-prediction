<?php
session_start();
include "db.php";
$msg="";

if(isset($_POST['login'])){
    $identifier=$_POST['identifier'];
    $pass=$_POST['password'];

    $r=$conn->query("SELECT * FROM users WHERE (email='$identifier' OR badge_id='$identifier') AND (role='user' OR role='police')");

    if($r->num_rows>0){
        $row=$r->fetch_assoc();
        if($pass == $row['password']){
            $_SESSION['uid']=$row['id'];
            $_SESSION['role']=$row['role'];
            header("Location: dashboard.php");
            exit();
        }else{
            $msg="<span class='msg'>Wrong Password!</span>";
        }
    }else{
        $msg="<span class='msg'>User Not Found!</span>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>User Login</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="box">
    <h2>User Login</h2>
    <form method="post">
        <div class="input-group">
            <input type="text" name="identifier" placeholder="Email or Badge ID" required>
        </div>
        <div class="input-group">
            <input type="password" name="password" placeholder="Password" required>
        </div>
        <button name="login">Login</button>
    </form>
    <div><?php echo $msg; ?></div>
    <div class="links" style="margin-top:20px;">
        <a href="user_register.php">Register as User/Police</a>
        <a href="user_forgot.php">Forgot Password?</a>
        <a href="index.html">Back to Home</a>
    </div>
</div>
</body>
</html>