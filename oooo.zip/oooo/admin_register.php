<?php
include "db.php";
$msg="";

if(isset($_POST['register'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $dob=$_POST['dob'];
    $mobile=$_POST['mobile'];
    $password=$_POST['password'];
    $cpassword=$_POST['cpassword'];
    $role='admin';

    if($password != $cpassword) {
        $msg="<span class='msg'>Passwords do not match!</span>";
    } else {
        $pass=$password;
        $check=$conn->query("SELECT * FROM users WHERE email='$email'");

        if($check->num_rows>0){
            $msg="<span class='msg'>Account with this email already exists!</span>";
        }else{
            $checkMobile=$conn->query("SELECT * FROM users WHERE mobile='$mobile'");
            if($checkMobile->num_rows>0){
                $msg="<span class='msg'>Mobile number already registered!</span>";
            } else {
                $c=$conn->query("SELECT * FROM users WHERE role='admin'");
                if($c->num_rows>=3){
                    $msg="<span class='msg'>Admin limit reached (3 only)</span>";
                }else{
                    $conn->query("INSERT INTO users(name,email,dob,mobile,password,role) VALUES('$name','$email','$dob','$mobile','$pass','$role')");
                    $msg="<span class='msg success'>Registration Success!</span>";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Register</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="box">
    <h2>Admin Register</h2>

    <form method="post">
        <div class="input-group">
            <input type="text" name="name" placeholder="Full Name" required>
        </div>
        <div class="input-group">
            <input type="email" name="email" placeholder="Email Address" required>
        </div>
        <div class="input-group">
            <input type="date" name="dob" placeholder="Date of Birth" required title="Date of Birth">
        </div>
        <div class="input-group">
            <input type="tel" name="mobile" placeholder="Mobile Number" required pattern="[0-9]{10}" title="10 digit mobile number">
        </div>
        <div class="input-group">
            <input type="password" name="password" placeholder="Password" required>
        </div>
        <div class="input-group">
            <input type="password" name="cpassword" placeholder="Confirm Password" required>
        </div>
        <button name="register">Register Admin</button>
    </form>
    
    <div><?php echo $msg; ?></div>

    <div class="links">
        <a href="admin_login.php">Already have an account? Login here</a>
        <a href="index.html">Back to Home</a>
    </div>
</div>

</body>
</html>